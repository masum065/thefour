# with-chakra-ui-typescript

npm i
npm run dev
