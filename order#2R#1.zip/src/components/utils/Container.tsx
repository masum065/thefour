import { Box, useColorMode } from '@chakra-ui/react';
import { FC } from 'react';

export const Container: FC = ({ children }) => {
  const { colorMode } = useColorMode();

  const bgColor = { light: 'gray.50', dark: 'black' };

  const color = { light: 'black', dark: 'white' };
  return (
    <Box
      overflowX={['hidden', 'hidden', 'visible']}
      // direction='column'
      bg={bgColor[colorMode]}
      color={color[colorMode]}
    >
      {children}
    </Box>
  );
};
